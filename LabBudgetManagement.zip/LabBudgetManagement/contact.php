
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lab Budget Management</title>
    <style>
        .custom-text-color {
            color: red;
        }
    </style>
</head>
<body>
   <div class="container-fluid bg-dark text-white-50 footer pt-5 mt-5">
    <div class="container py-5">
        <div class="pb-4 mb-4" style="border-bottom: 1px solid rgba(226, 175, 24, 0.5);">
            <div class="row g-4">
                <div class="col-lg-3">
                    <a href="#"></a>
                </div>
                <div class="col-lg-6">
                    <div class="position-relative mx-auto">
                        <br>
                        <br>
                        <br>
                        <h1 align="center">K. K. Wagh Education Society's K. K. Wagh Polytechnic, Nashik</h1>
						 <h1 align="center" class="text-primary mb-0 custom-text-color">Contact Us</h1>
                        <br>
                        <br>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
					<h1>1. Shiwani Nanaware <br>
					mob: 7498041212 ,	 email: shiwaninanaware@gmail.com</h1>
					<h1>2. Nivrutti Chaudhari <br>
					mob: 9021697514 , email: nivruttichaudhari54@gmail.com</h1>
					<h1>3. Madhura Patil <br>
					mob: 8999430439 ,  email: madhura.patil2909@gmail.com</h1>
					<h1>4. Shraddha More  <br>
					mob: 9325849318 , email: moreshraddha1112@gmail.com</h1>


</body>
</html>